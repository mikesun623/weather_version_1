//
//  api_control.swift
//  weather report
//
//  Created by mike on 17/1/27.
//  Copyright © 2017年 my_application. All rights reserved.
//

import Foundation

class Settings{
    var viewPosts = "http://api.openweathermap.org/data/2.5/weather?id=4163971&units=
    
    metric&APPID=5933986010b65a4181c8994f3d137bb2"
    //api for sydney

}

class post{
    var coord:String?
    var weather:String?
    var base:String?
    var main:String?
    var wind:String?
    var clouds:String?
    var dt:String?
    var sys:String?
    var id:String?
    var name:String?
    var cod:String?
}